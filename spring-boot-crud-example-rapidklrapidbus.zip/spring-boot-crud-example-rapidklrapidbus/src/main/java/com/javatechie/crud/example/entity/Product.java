package com.javatechie.crud.example.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "RAPIDBUS_TBL")
public class Product {

    @Id
    @GeneratedValue
    private char name;
    private int id_number;
    private int bus_number;
    private char bus_model;
    private char maintenance_order;
    private float time_Start;
    private float time_Completed;
    private char item_front_visual_check;
    private char item_front_hardness_and_earthing_check;
    private char side_visual_check;
    private char side_hardness_and_earthing_check;
    private char rear_visual_check;
    private char rear_front_hardness_and_earthing_check;
    private char controller_content_check;
    private char controller_visual_check;
    private char truck_radio_visual_check;
    private char truck_radio_hardness_earthing_check;
    private char truck_radio_content_check;
    private char tracker_visual_check;
    private char tracker_hardness_earthing_check;
    private char tracker_panic_button;
    private char tracker_CBTS_cable;
    private char announcerment_player_visual_check;
    private char announcerment_player_hardness_earthing_check;
    private char announcerment_player_content_check;
    private char announcerment_player_speaker;
    private char announcerment_player_microphone;
    private char infortainment_sys_LCD_Monitor_Front;
    private char infortainment_sys_LCD_Monitor_Rear;
    private char infortainment_sys_Visual_check;
    private char infortainment_sys_Hardness_and_earthing_check;
    private char CCTV_sys_item_LCD_Monitor;
    private char CCTV_sys_item_Camera_Condition;
    private char CCTV_sys_item_Visual_Check;
    private char CCTV_sys_item_Hardness_and_earthing_check;
    private char CCTV_sys_item_DVR_NVR;
    private char FCS_CBTS_ETM_Visual_Check;
    private char FCS_CBTS_ETM_Hardness_and_Earthing_Check;
    private char FCS_CBTS_Reader_Visual_Check;
    private char FCS_CBTS_Reader_Hardness_and_Earthing_Check;
    private char FCS_BTS_Reader_Visual_Check;
    private char FCS_BTS_Reader_Hardness_and_Earthing_Check;
    private char FCS_Cash_Vault_lock_condition;
    private char FCS_Cash_Vault_visual_check;
}
