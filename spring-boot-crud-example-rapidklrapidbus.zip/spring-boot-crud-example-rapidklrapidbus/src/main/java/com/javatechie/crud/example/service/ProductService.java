package com.javatechie.crud.example.service;

import com.javatechie.crud.example.entity.Product;
import com.javatechie.crud.example.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {
    @Autowired
    private ProductRepository repository;

    public Product saveProduct (Product product) {
        return repository.save(product);
    }
    public List<Product> saveProducts (List<Product> products) {
        return repository.saveAll(products);
    }

    public List<Product> getProducts() {
        return repository.findAll();
    }
    public Product getProductsById(int id_number) {
        return repository.findById(id_number).orElse(null);
    }
        public Product getProductsByName(String name) {
            return repository.findByName(name);
    }

    public String deleteProduct(int id_number) {
        repository.deleteById(id_number);
        return "product removed !!"+id_number;
    }

    public Product updateProduct(Product product){
        Product existingProduct = repository.findById(product.getid_number()).orElse(null);
        existingProduct.setid_number(product.getid_number());
        existingProduct.setname(product.getname());
        existingProduct.setbus_number(product.getbus_number());
        existingProduct.setbus_model(product.getbus_model());
        existingProduct.setmaintenance_order(product.getmaintenance_order());
        existingProduct.settime_Start(product.gettime_Start());
        existingProduct.settime_Completed(product.gettime_Completed());
        existingProduct.setitem_front_visual_check(product.getitem_front_visual_check());
        existingProduct.setitem_front_hardness_and_earthing_check(product.getitem_front_hardness_and_earthing_check());
        existingProduct.setside_visual_check(product.getside_visual_check());
        existingProduct.setside_hardness_and_earthing_check(product.getside_hardness_and_earthing_check());
        existingProduct.setrear_visual_check(product.getrear_visual_check());
        existingProduct.setrear_front_hardness_and_earthing_check(product.getrear_front_hardness_and_earthing_check());
        existingProduct.setcontroller_content_check(product.getcontroller_content_check());
        existingProduct.setcontroller_visual_check(product.getcontroller_visual_check());
        existingProduct.settruck_radio_visual_check(product.gettruck_radio_visual_check());
        existingProduct.settruck_radio_hardness_earthing_check(product.gettruck_radio_hardness_earthing_check());
        existingProduct.settruck_radio_content_check(product.gettruck_radio_content_check());
        existingProduct.settracker_visual_check(product.gettracker_visual_check());
        existingProduct.settracker_hardness_earthing_check(product.gettracker_hardness_earthing_check());
        existingProduct.settracker_panic_button(product.gettracker_panic_button());
        existingProduct.settracker_CBTS_cable(product.gettracker_CBTS_cable());
        existingProduct.setannouncerment_player_visual_check(product.getannouncerment_player_visual_check());
        existingProduct.setannouncerment_player_hardness_earthing_check(product.getannouncerment_player_hardness_earthing_check());
        existingProduct.setannouncerment_player_content_check(product.getannouncerment_player_content_check());
        existingProduct.setannouncerment_player_speaker(product.getannouncerment_player_speaker());
        existingProduct.setannouncerment_player_microphone(product.getannouncerment_player_microphone());
        existingProduct.setinfortainment_sys_LCD_Monitor_Front(product.getinfortainment_sys_LCD_Monitor_Front());
        existingProduct.setinfortainment_sys_LCD_Monitor_Rear(product.getinfortainment_sys_LCD_Monitor_Rear());
        existingProduct.setinfortainment_sys_Visual_check(product.getinfortainment_sys_Visual_check());
        existingProduct.setinfortainment_sys_Hardness_and_earthing_check(product.getinfortainment_sys_Hardness_and_earthing_check());
        existingProduct.setCCTV_sys_item_LCD_Monitor(product.getCCTV_sys_item_LCD_Monitor());
        existingProduct.setCCTV_sys_item_Camera_Condition(product.getCCTV_sys_item_Camera_Condition());
        existingProduct.setCCTV_sys_item_Visual_Check(product.getCCTV_sys_item_Visual_Check());
        existingProduct.setCCTV_sys_item_Hardness_and_earthing_check(product.getCCTV_sys_item_Hardness_and_earthing_check());
        existingProduct.setCCTV_sys_item_DVR_NVR(product.getCCTV_sys_item_DVR_NVR());
        existingProduct.setFCS_CBTS_ETM_Visual_Check(product.getFCS_CBTS_ETM_Visual_Check());
        existingProduct.setFCS_CBTS_ETM_Hardness_and_Earthing_Check(product.getFCS_CBTS_ETM_Hardness_and_Earthing_Check());
        existingProduct.setFCS_CBTS_Reader_Visual_Check(product.getFCS_CBTS_Reader_Visual_Check());
        existingProduct.setFCS_CBTS_Reader_Hardness_and_Earthing_Check(product.getFCS_CBTS_Reader_Hardness_and_Earthing_Check());
        existingProduct.setFCS_BTS_Reader_Visual_Check(product.getFCS_BTS_Reader_Visual_Check());
        existingProduct.setFCS_BTS_Reader_Hardness_and_Earthing_Check(product.getFCS_BTS_Reader_Hardness_and_Earthing_Check);
        existingProduct.setFCS_Cash_Vault_lock_condition(product.getFCS_Cash_Vault_lock_condition());
        existingProduct.setFCS_Cash_Vault_visual_check(product.getFCS_Cash_Vault_visual_check());
        return repository.save(existingProduct);
    }







}
